import java.util.Scanner;

/**
 * Represents a customer in the store system.
 * A customer has a location, a shopping cart, and a linked list of orders.
 */
class Customer extends User {
    private String location;
    private ShoppingCart shopC;
    private LinkedListNode<Order> ordersHead;
    private LinkedListNode<Order> ordersTail;
    private int countOrder;

    /**
     * Creates a new customer with personal information, location, and account.
     *
     * @param id the customer ID
     * @param name the customer name
     * @param email the customer email
     * @param location the customer location
     * @param account the customer's login account
     */
    public Customer(int id, String name, String email, String location, Account account) {
        super(id, name, email);
        setAccount(account);
        this.location = location;
        this.shopC = new ShoppingCart();
        this.ordersHead = null;
        this.ordersTail = null;
        this.countOrder = 0;
    }

    /**
     * Adds an order to the customer's linked list of orders.
     *
     * @param order the order to add
     * @return true if the order was added successfully, otherwise false
     */
    public boolean addOrder(Order order) {
        if (order == null) return false;

        LinkedListNode<Order> newNode = new LinkedListNode<>(order);
        if (ordersHead == null) {
            ordersHead = newNode;
            ordersTail = newNode;
        } else {
            ordersTail.setNext(newNode);
            ordersTail = newNode;
        }
        countOrder++;
        return true;
    }

    /**
     * Searches for an order in the customer's order history using its ID.
     *
     * @param orderId the order ID to search for
     * @return the matching order if found, otherwise null
     */
    public Order searchOrder(int orderId) {
        LinkedListNode<Order> current = ordersHead;
        while (current != null) {
            if (current.getData() != null && current.getData().getId() == orderId) {
                return current.getData();
            }
            current = current.getNext();
        }
        return null;
    }

    /**
     * Starts the checkout process for the current cart.
     * Displays cart details, asks the user for confirmation, and creates an order if confirmed.
     *
     * @return the created order if checkout succeeds, otherwise null
     */
    public Order checkout() {
        Scanner sc = new Scanner(System.in);
        shopC.displayCartItems();
        System.out.println("Total = " + shopC.calculateTotal());
        System.out.println("If you want to checkout press 1, if you want to clear the cart press 2");
        int choice;
        try {
            choice = sc.nextInt();
        } catch (java.util.InputMismatchException ex) {
            System.out.println("Invalid input. Checkout cancelled.");
            sc.nextLine();
            return null;
        }

        if (choice == 1) {
            Order order = new Order(this, shopC);
            addOrder(order);
            shopC.clearCart();
            return order;
        } else if (choice == 2) {
            shopC.clearCart();
        }
        return null;
    }

    /**
     * Displays all orders in the customer's order history using console output.
     */
    public void viewOrders() {
        if (countOrder == 0) {
            System.out.println("You have no orders.");
            return;
        }
        LinkedListNode<Order> current = ordersHead;
        while (current != null) {
            if (current.getData() != null) {
                current.getData().printOrder();
            }
            current = current.getNext();
        }
    }

    /**
     * Returns the customer's order history as formatted text for the GUI.
     *
     * @return the order history text
     */
    public String getOrdersText() {
        if (countOrder == 0) {
            return "You have no orders.";
        }

        StringBuilder sb = new StringBuilder();
        LinkedListNode<Order> current = ordersHead;
        while (current != null) {
            if (current.getData() != null) {
                sb.append(current.getData().getOrderText()).append("\n");
            }
            current = current.getNext();
        }
        return sb.toString();
    }

    /**
     * Returns the role of this user.
     *
     * @return the role name as Customer
     */
    public String getRole() {
        return "Customer";
    }

    /**
     * Updates the customer's location.
     *
     * @param location the new customer location
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * Returns the customer's location.
     *
     * @return the customer location
     */
    public String getlocation() {
        return location;
    }

    /**
     * Returns the customer's name.
     *
     * @return the customer name
     */
    public String getName() {
        return super.getName();
    }

    /**
     * Returns the customer's shopping cart.
     *
     * @return the shopping cart
     */
    public ShoppingCart getCart() {
        return shopC;
    }
}
