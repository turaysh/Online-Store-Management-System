/**
 * Represents the store system.
 * It manages users, items, login, validation, searching, and stock updates.
 */

class Store implements searchable {
    private String name;
    private LinkedListNode<Item> itemsHead;
    private LinkedListNode<Item> itemsTail;
    private int nofItem;
    private int userCount;
    private LinkedListNode<User> usersHead;
    private LinkedListNode<User> usersTail;

    /**
     * Creates a new store with empty linked lists for users and items.
     *
     * @param name the name of the store
     */
    public Store(String name) {
        this.name = name;
        this.itemsHead = null;
        this.itemsTail = null;
        this.nofItem = 0;
        this.userCount = 0;
        this.usersHead = null;
        this.usersTail = null;
    }

    /**
     * Adds a user to the store system.
     *
     * @param user the user to add
     * @return true if added successfully, otherwise false
     */
    public boolean addUser(User user) {
        if (user == null) return false;

        LinkedListNode<User> newNode = new LinkedListNode<>(user);
        if (usersHead == null) {
            usersHead = newNode;
            usersTail = newNode;
        } else {
            usersTail.setNext(newNode);
            usersTail = newNode;
        }
        userCount++;
        return true;
    }

    /**
     * Checks if a username already exists in the system.
     *
     * @param username the username to check
     * @return true if it exists, otherwise false
     */
    public boolean usernameExists(String username) {
        LinkedListNode<User> current = usersHead;
        while (current != null) {
            if (current.getData() != null &&
                current.getData().getUsername() != null &&
                current.getData().getUsername().equalsIgnoreCase(username)) {
                return true;
            }
            current = current.getNext();
        }
        return false;
    }

    /**
     * Validates username rules.
     *
     * @param username the username to validate
     * @return true if valid, otherwise false
     */
    public boolean isValidUsername(String username) {
        return username != null &&
            username.length() >= 4 &&
            !username.contains(" ") &&
            username.matches("[A-Za-z0-9_]+");
    }

    /**
     * Validates password rules.
     *
     * @param password the password to validate
     * @return true if valid, otherwise false
     */
    public boolean isValidPassword(String password) {
        return password != null && 
           !password.contains(" ") &&
            password.length() >= 6 &&
            password.matches(".*\\d.*");
    }

    /**
     * Generates the next user ID based on the current number of users.
     *
     * @return the next available user ID
     */
    public int getNextUserId() {
        return userCount + 1;
    }

    /**
     * Adds an item to the store items linked list.
     * Throws a DuplicateItemException if another item with the same ID already exists.
     *
     * @param item the item to add
     * @return true if the item is added successfully, otherwise false
     * @throws DuplicateItemException if an item with the same ID already exists
     */
    public boolean addItem(Item item) {
        if (item == null) return false;
        if (itemIdExists(item.getId())) {
            throw new DuplicateItemException(item.getId());
        }

        LinkedListNode<Item> newNode = new LinkedListNode<>(item);
        if (itemsHead == null) {
            itemsHead = newNode;
            itemsTail = newNode;
        } else {
            itemsTail.setNext(newNode);
            itemsTail = newNode;
        }
        nofItem++;
        return true;
    }

    /**
     * Removes an item from the store using its item ID.
     *
     * @param itemId the ID of the item to remove
     * @return true if the item is removed successfully, otherwise false
     */
    public boolean removeItem(int itemId) {
        LinkedListNode<Item> current = itemsHead;
        LinkedListNode<Item> prev = null;

        while (current != null) {
            if (current.getData() != null && current.getData().getId() == itemId) {
                if (prev == null) {
                    itemsHead = current.getNext();
                } else {
                    prev.setNext(current.getNext());
                }
                if (current == itemsTail) {
                    itemsTail = prev;
                }
                nofItem--;
                return true;
            }
            prev = current;
            current = current.getNext();
        }
        return false;
    }

    /**
     * Checks if an item id already exists.
     *
     * @param id the item id
     * @return true if the id exists, otherwise false
     */
    public boolean itemIdExists(int id) {
        LinkedListNode<Item> current = itemsHead;
        while (current != null) {
            if (current.getData() != null && current.getData().getId() == id) {
                return true;
            }
            current = current.getNext();
        }
        return false;
    }

    /**
     * Updates the stock of a given item.
     *
     * @param itemId the item id
     * @param newStock the new stock amount
     * @return true if updated successfully, otherwise false
     */
    public boolean updateStock(int itemId, int newStock) {
        LinkedListNode<Item> current = itemsHead;
        while (current != null) {
            if (current.getData().getId() == itemId) {
                current.getData().setStock(newStock);
                return true;
            }
            current = current.getNext();
        }
        return false;
    }

    /**
     * Displays all items in the store using console output.
     */
    public void displayAllItems() {
        if (itemsHead == null) {
            System.out.println("No items available.");
            return;
        }
        LinkedListNode<Item> current = itemsHead;
        while (current != null) {
            System.out.println(current.getData().toString());
            current = current.getNext();
        }
    }

    /**
     * Builds and returns all store items as formatted text for GUI display.
     *
     * @return a formatted string containing all store items
     */
    public String getAllItemsText() {
        if (itemsHead == null) {
            return "No items available.";
        }

        StringBuilder sb = new StringBuilder();
        LinkedListNode<Item> current = itemsHead;
        while (current != null) {
            if (current.getData() != null) {
                sb.append(current.getData().toString()).append("\n");
            }
            current = current.getNext();
        }
        return sb.toString();
    }

    /**
     * Recursively counts items that are still available in stock.
     *
     * @param node the current node
     * @return number of available items
     */
    public int countAvailableItemsRecursive(LinkedListNode<Item> node) {
        if (node == null) return 0;
        int count = (node.getData().getStock() > 0) ? 1 : 0;
        return count + countAvailableItemsRecursive(node.getNext());
    }

    /**
     * Counts items available in stock (overloaded for backward compatibility).
     *
     * @param index the starting index (ignored, kept for compatibility)
     * @return number of available items
     */
    public int countAvailableItemsRecursive(int index) {
        return countAvailableItemsRecursive(itemsHead);
    }

    /**
     * Returns the store name.
     *
     * @return the store name
     */
    public String getName() {
        return name;
    }

    /**
     * Logs in a user using username and password.
     *
     * @param username entered username
     * @param password entered password
     * @return the matching user if login succeeds, otherwise null
     */
    public User login(String username, String password) {
        LinkedListNode<User> current = usersHead;
        while (current != null) {
            if (current.getData() != null &&
                current.getData().getUsername() != null &&
                current.getData().getPassword() != null &&
                current.getData().getUsername().equals(username) &&
                current.getData().getPassword().equals(password)) {
                return current.getData();
            }
            current = current.getNext();
        }
        return null;
    }

    /**
     * Searches for an item in the store using its item ID.
     *
     * @param itemId the ID of the item to search for
     * @return the matching item if found, otherwise null
     */
    public Item searchItemById(int itemId) {
        LinkedListNode<Item> current = itemsHead;
        while (current != null) {
            if (current.getData().getId() == itemId) {
                return current.getData();
            }
            current = current.getNext();
        }
        return null;
    }

    /**
     * Searches for an item in the store using its name.
     *
     * @param name the item name to search for
     * @return the matching item if found, otherwise null
     */
    public Item searchByName(String name) {
        LinkedListNode<Item> current = itemsHead;
        while (current != null) {
            if (current.getData().getName().equalsIgnoreCase(name)) {
                return current.getData();
            }
            current = current.getNext();
        }
        return null;
    }

    /**
     * Reduces store stock based on the items found in a shopping cart.
     *
     * @param cart the shopping cart used for checkout
     */
    public void reduceStockFromCart(ShoppingCart cart) {
        LinkedListNode<Item> cartHead = cart.getItemsHead();

        while (cartHead != null) {
            if (cartHead.getData() != null) {
                Item cartItem = cartHead.getData();
                Item storeItem = searchItemById(cartItem.getId());
                if (storeItem != null) {
                    int newStock = storeItem.getStock() - 1;
                    storeItem.setStock(Math.max(0, newStock));
                }
            }
            cartHead = cartHead.getNext();
        }
    }

    /**
     * Returns the number of items currently stored in the store.
     *
     * @return the number of items in the store
     */
    public int getNofItem() {
        return nofItem;
    }

    /**
     * Returns the head of the items linked list (for FileManager to iterate).
     *
     * @return the head node of the items list
     */
    public LinkedListNode<Item> getItemsHead() {
        return itemsHead;
    }

    /**
     * Returns the head of the users linked list (for FileManager to iterate).
     *
     * @return the head node of the users list
     */
    public LinkedListNode<User> getUsersHead() {
        return usersHead;
    }
}
